INFORMATIONS
==================
Sous le répertoire "Merchants", il faut créer un répertoire par magasin. 
Ces répertoires doivent porter le nom de "Merchant ID" provenant du dashboard Clover.



Listes de vos magasins : 
===============================================

Drummondville : XXXMERCHANT_IDXXX

Sainte-Hyacinthe : XXXMERCHANT_IDXXX

Acton Vale : XXXMERCHANT_IDXXX

Trois-Rivière : XXXMERCHANT_IDXXX



*************************************************
** À faire une seule fois par magasin au début **
*************************************************
1 : Sous chacun des sous-répertoires de magasin il faut créer un fichier texte nommé : clover_auth_code.txt
2 : Ouvrir un navigateur web et connectez-vous à votre environnement dashboard Clover.
3 : Copier le lien ci-dessous dans un navigateur web pour générer un code d'autorisation pour un magasin. 
    ************************************************************************************
    *** ATTENTION : Ne pas choisir le mauvais magasin qui aurait déjà été initialisé
    *** ATTENTION : Ce briserait son accès et les terminaux ne fonctionneront plus
    ************************************************************************************

POUR ENVIRONNEMENT SANDBOX : https://sandbox.dev.clover.com/oauth/v2/authorize?client_id=64ZNT0RZQF2ME
POUR ENVIRONNEMENT PRODUCTION : https://www.clover.com/oauth/v2/authorize?client_id=64ZNT0RZQF2ME

4 : Copier le code affiché à l'écran suite à l'étape 3 et sauvegarder dans le fichier clover_auth_code.txt du magasin concerné.

FIN - Ce magasin peut utiliser les terminaux Clover
Lors de la première utilisation d'un terminal pour un magasin, un fichier : clover_tokens.json sera automatiquement créé. 
** NE JAMAIS MODIFIER CE FICHIER MANUELLEMENT





Listes des environnements TEST (Sandbox) :
===============================================

Dominic Belley : 61AQWNQWJYFG1





